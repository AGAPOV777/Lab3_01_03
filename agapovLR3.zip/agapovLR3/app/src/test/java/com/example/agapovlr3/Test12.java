package com.example.agapovlr3;

import org.junit.Test;

public class Test12 {

    @Test
    public void test() {
        Circle c1 = new Circle();
        System.out.println(c1);
        Cylinder cyl1 = new Cylinder( );
        System.out.println(cyl1);
    }
}
